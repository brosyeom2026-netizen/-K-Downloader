# K Downloader Pro Version 2.2 — Copyright by : YEOM BROS
- Fixed RedNote (xhslink.com / Xiaohongshu) watermark removal by extracting raw originVideoKey CDN streams first
- Prioritizes unwatermarked media options across RapidAPI and direct extractors
- Includes HH:MM:SS duration badge, Night/Day & Color Theme switcher, and full-screen edge-to-edge layout
