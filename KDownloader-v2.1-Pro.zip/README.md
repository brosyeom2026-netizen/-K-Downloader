# K Downloader Pro Version 2.1 — Copyright by : YEOM BROS
- Fixed video duration badge formatting to clean HH:MM:SS (automatically converts millisecond durations from Facebook Reels & other APIs)
- Includes RedNote (xhslink.com), Instagram, Pinterest, Douyin, Kuaishou, TikTok, FB Reels, and YouTube support
- Includes top-right Night/Day & Color Theme switcher and full-screen edge-to-edge layout
