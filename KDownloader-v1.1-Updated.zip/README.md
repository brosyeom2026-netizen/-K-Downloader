# K Downloader v1.1
- Fixed POST API request for Social Download All In One
- Added in-app Key button (top right) so you can paste & save your RapidAPI key directly on your phone!
