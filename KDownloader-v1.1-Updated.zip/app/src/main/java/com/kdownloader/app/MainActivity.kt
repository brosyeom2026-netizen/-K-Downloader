package com.kdownloader.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class VideoInfo(
    val title: String,
    val platform: String,
    val thumbnailUrl: String,
    val hdVideoUrl: String,
    val sdVideoUrl: String,
    val mp3AudioUrl: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KDownloaderApp()
        }
    }
}

@Composable
fun KDownloaderApp() {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val prefs = remember {
        context.getSharedPreferences("kdownloader_prefs", Context.MODE_PRIVATE)
    }

    var savedApiKey by remember {
        mutableStateOf(prefs.getString("rapidapi_key", "") ?: "")
    }
    var showApiDialog by remember { mutableStateOf(false) }
    var tempKeyInput by remember { mutableStateOf(savedApiKey) }

    var urlInput by remember { mutableStateOf("") }
    var isFetching by remember { mutableStateOf(false) }
    var videoInfo by remember { mutableStateOf<VideoInfo?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val rapidApiHost = "social-download-all-in-one.p.rapidapi.com"

    val gradientBrush = Brush.horizontalGradient(
        colors = listOf(Color(0xFF6366F1), Color(0xFFEC4899))
    )

    fun detectPlatform(url: String): String {
        val lower = url.lowercase()
        return when {
            lower.contains("tiktok.com") -> "TikTok"
            lower.contains("facebook.com") || lower.contains("fb.watch") -> "Facebook Reels"
            lower.contains("youtu.be") || lower.contains("youtube.com") -> {
                if (lower.contains("/shorts/")) "YouTube Shorts" else "YouTube HD"
            }
            else -> "Social Video"
        }
    }

    fun fetchVideoDetails(link: String) {
        val cleanUrl = link.trim()
        if (cleanUrl.isEmpty()) {
            errorMessage = "Please paste a valid video link first."
            return
        }
        if (savedApiKey.isBlank()) {
            errorMessage = "Tap the Key icon in the top-right corner to paste your free RapidAPI key first."
            showApiDialog = true
            return
        }

        errorMessage = null
        videoInfo = null
        isFetching = true

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val client = OkHttpClient.Builder()
                        .connectTimeout(25, TimeUnit.SECONDS)
                        .readTimeout(25, TimeUnit.SECONDS)
                        .build()

                    val jsonBody = JSONObject().put("url", cleanUrl).toString()
                    val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

                    val request = Request.Builder()
                        .url("https://$rapidApiHost/v1/social/autolink")
                        .post(requestBody)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("x-rapidapi-key", savedApiKey.trim())
                        .addHeader("x-rapidapi-host", rapidApiHost)
                        .build()

                    client.newCall(request).execute().use { response ->
                        val body = response.body?.string() ?: throw Exception("Empty response from server")
                        if (!response.isSuccessful) {
                            throw Exception("API Error (${response.code}): Check your RapidAPI key or subscription.")
                        }
                        val json = JSONObject(body)
                        if (json.optBoolean("error", false)) {
                            throw Exception(json.optString("message", "Could not extract video from this link."))
                        }

                        val title = json.optString("title", "KDownloader Video").ifBlank { "KDownloader Video" }
                        val thumb = json.optString("thumbnail", "")
                        val medias = json.optJSONArray("medias")

                        var hdUrl = ""
                        var sdUrl = ""
                        var mp3Url = ""

                        if (medias != null) {
                            for (i in 0 until medias.length()) {
                                val item = medias.getJSONObject(i)
                                val ext = item.optString("extension", "").lowercase()
                                val quality = item.optString("quality", "").lowercase()
                                val type = item.optString("type", "").lowercase()
                                val mediaUrl = item.optString("url", "")

                                if (mediaUrl.isBlank()) continue

                                if (ext == "mp4" || type == "video") {
                                    if (hdUrl.isEmpty() || quality.contains("1080") || quality.contains("hd") || quality.contains("no watermark")) {
                                        hdUrl = mediaUrl
                                    }
                                    if (sdUrl.isEmpty()) {
                                        sdUrl = mediaUrl
                                    }
                                }
                                if (ext == "mp3" || ext == "m4a" || type == "audio") {
                                    if (mp3Url.isEmpty()) {
                                        mp3Url = mediaUrl
                                    }
                                }
                            }
                        }

                        if (hdUrl.isEmpty() && sdUrl.isEmpty()) {
                            throw Exception("No downloadable video streams found for this link.")
                        }

                        VideoInfo(
                            title = title,
                            platform = detectPlatform(cleanUrl),
                            thumbnailUrl = thumb,
                            hdVideoUrl = hdUrl.ifEmpty { sdUrl },
                            sdVideoUrl = sdUrl.ifEmpty { hdUrl },
                            mp3AudioUrl = mp3Url.ifEmpty { hdUrl.ifEmpty { sdUrl } }
                        )
                    }
                }
                videoInfo = result
            } catch (e: Exception) {
                errorMessage = e.localizedMessage ?: "Failed to fetch video."
            } finally {
                isFetching = false
            }
        }
    }

    fun startSystemDownload(downloadUrl: String, fileName: String, mimeType: String) {
        if (downloadUrl.isBlank()) {
            Toast.makeText(context, "Download link unavailable.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val request = DownloadManager.Request(Uri.parse(downloadUrl))
                .setTitle(fileName)
                .setDescription("Downloading via K Downloader")
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(context, "Downloading $fileName to Downloads folder...", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    if (showApiDialog) {
        AlertDialog(
            onDismissRequest = { showApiDialog = false },
            containerColor = Color(0xFF1E293B),
            title = { Text("RapidAPI Key Setup", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Paste your free X-RapidAPI-Key from 'Social Download All In One' on RapidAPI:",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = tempKeyInput,
                        onValueChange = { tempKeyInput = it },
                        placeholder = { Text("Paste RapidAPI Key...", color = Color(0xFF64748B)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF6366F1),
                            unfocusedBorderColor = Color(0xFF475569)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        savedApiKey = tempKeyInput.trim()
                        prefs.edit().putString("rapidapi_key", savedApiKey).apply()
                        showApiDialog = false
                        Toast.makeText(context, "API Key saved!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                ) {
                    Text("Save Key", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiDialog = false }) {
                    Text("Cancel", color = Color(0xFF94A3B8))
                }
            }
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Top Bar with API Key Setup Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(gradientBrush),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "K",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Column {
                        Text(
                            text = "K Downloader",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "FB Reels • TikTok • YouTube & Shorts",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                    }
                }

                IconButton(
                    onClick = {
                        tempKeyInput = savedApiKey
                        showApiDialog = true
                    },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Key,
                        contentDescription = "API Key Settings",
                        tint = if (savedApiKey.isNotBlank()) Color(0xFF4ADE80) else Color(0xFFFBBF24)
                    )
                }
            }

            // Platform Badges
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf("YouTube", "Shorts", "TikTok", "FB Reels").forEach { label ->
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), CircleShape)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = label, color = Color(0xFFE2E8F0), fontSize = 12.sp)
                    }
                }
            }

            // Link Input Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF1E293B))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Paste video link here...", color = Color(0xFF64748B)) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF0F172A),
                        unfocusedContainerColor = Color(0xFF0F172A)
                    ),
                    trailingIcon = {
                        if (urlInput.isNotEmpty()) {
                            IconButton(onClick = { urlInput = ""; videoInfo = null; errorMessage = null }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color(0xFF94A3B8))
                            }
                        }
                    }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val pastedText = clipboardManager.getText()?.text ?: ""
                            if (pastedText.isNotBlank()) {
                                urlInput = pastedText
                                fetchVideoDetails(pastedText)
                            } else {
                                Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6366F1))
                    ) {
                        Icon(Icons.Rounded.ContentPaste, contentDescription = null, tint = Color(0xFF818CF8))
                        Spacer(Modifier.width(6.dp))
                        Text("Paste Link", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = { fetchVideoDetails(urlInput) },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(gradientBrush),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Search, contentDescription = null, tint = Color.White)
                                Spacer(Modifier.width(6.dp))
                                Text("Fetch Video", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            if (isFetching) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF1E293B))
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(color = Color(0xFFEC4899))
                    Text("Fetching video info...", color = Color(0xFFE2E8F0), fontSize = 15.sp)
                }
            }

            errorMessage?.let { msg ->
                Text(
                    text = msg,
                    color = Color(0xFFF87171),
                    fontSize = 14.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF450A0A))
                        .padding(14.dp)
                )
            }

            AnimatedVisibility(visible = videoInfo != null) {
                videoInfo?.let { info ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(22.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(195.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF0F172A))
                        ) {
                            AsyncImage(
                                model = info.thumbnailUrl,
                                contentDescription = "Video Thumbnail",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xAA0F172A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Text(
                                text = info.platform,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(10.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xCC6366F1))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = info.title,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Button(
                            onClick = {
                                val fileName = "KDownloader_${System.currentTimeMillis()}.mp4"
                                startSystemDownload(info.hdVideoUrl, fileName, "video/mp4")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            contentPadding = PaddingValues()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(gradientBrush),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Hd, contentDescription = null, tint = Color.White)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "Download HD Video (MP4)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                val fileName = "KDownloader_${System.currentTimeMillis()}.mp3"
                                startSystemDownload(info.mp3AudioUrl, fileName, "audio/mpeg")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEC4899))
                        ) {
                            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color(0xFFF472B6))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Download Audio Only (MP3)",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
