# K Downloader Pro Version 2.0 — Copyright by : YEOM BROS
- Updated subtitle under K Downloader to "Pro Version 2.0"
- Added RedNote (Xiaohongshu / xhslink.com) video extraction & no-watermark download support
- Added top-right Theme & Night/Day Color Switcher button (Midnight Night, Ocean Emerald, Crimson Sunset, Daylight Studio)
- Fixed full-screen edge-to-edge WindowInsets layout across Android status & navigation bars
