# K Downloader v1.8 — Copyright by : YEOM BROS
- Removed the Key icon from the bottom dock and replaced it with the official Telegram Support logo opening https://t.me/Mr_BROS_Kh
- Added direct "Contact Admin on Telegram" button on the Activation Lock screen
- API Key configuration remains accessible inside the hidden 5-tap Admin Control Panel (PIN: 1688)
