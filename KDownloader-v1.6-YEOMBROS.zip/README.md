# K Downloader v1.6 — Copyright by : YEOM BROS
- Live % download progress bar & transferred MB counter directly on screen
- Added Instagram, Pinterest, Douyin, and Kuaishou download support alongside TikTok, Facebook Reels, and YouTube
- Added YEOM BROS Admin Control Panel (Request ID lock screen, Approval Code generator, PIN protection, and API key management)
