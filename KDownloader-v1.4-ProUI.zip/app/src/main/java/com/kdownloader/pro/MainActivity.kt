package com.kdownloader.pro

import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class VideoInfo(
    val title: String,
    val platform: String,
    val thumbnailUrl: String,
    val hdVideoUrl: String,
    val mp3AudioUrl: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedText = if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            extractFirstUrl(intent.getStringExtra(Intent.EXTRA_TEXT) ?: "")
        } else {
            ""
        }

        setContent {
            KDownloaderApp(initialSharedUrl = sharedText)
        }
    }

    private fun extractFirstUrl(text: String): String {
        val matcher = Pattern.compile("(https?://\\S+)").matcher(text)
        return if (matcher.find()) matcher.group(1) ?: text else text
    }
}

@Composable
fun KDownloaderApp(initialSharedUrl: String = "") {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val prefs = remember {
        context.getSharedPreferences("kdownloader_v4_prefs", Context.MODE_PRIVATE)
    }

    var customRapidKey by remember {
        mutableStateOf(prefs.getString("rapidapi_key", "") ?: "")
    }
    var showApiDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var tempKeyInput by remember { mutableStateOf(customRapidKey) }

    var urlInput by remember { mutableStateOf(initialSharedUrl) }
    var isFetching by remember { mutableStateOf(false) }
    var videoInfo by remember { mutableStateOf<VideoInfo?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val analyzeGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF6366F1), Color(0xFFA855F7), Color(0xFFD946EF))
    )

    val hdCyanGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF38BDF8), Color(0xFF60A5FA), Color(0xFF818CF8))
    )

    fun detectPlatform(url: String): String {
        val lower = url.lowercase()
        return when {
            lower.contains("tiktok.com") -> "TikTok"
            lower.contains("facebook.com") || lower.contains("fb.watch") -> "Facebook Reels"
            lower.contains("youtu.be") || lower.contains("youtube.com") -> {
                if (lower.contains("/shorts/")) "YouTube Shorts" else "YouTube HD"
            }
            lower.contains("douyin.com") -> "Douyin"
            lower.contains("kuaishou.com") -> "Kuaishou"
            else -> "Social Video"
        }
    }

    fun extractUrlFromText(raw: String): String {
        val matcher = Pattern.compile("(https?://\\S+)").matcher(raw.trim())
        return if (matcher.find()) matcher.group(1) ?: raw.trim() else raw.trim()
    }

    fun fetchVideoDetails(rawLink: String) {
        val cleanUrl = extractUrlFromText(rawLink)
        if (cleanUrl.isEmpty() || !cleanUrl.startsWith("http")) {
            errorMessage = "Please paste a valid video link first."
            return
        }
        urlInput = cleanUrl
        errorMessage = null
        videoInfo = null
        isFetching = true

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val client = OkHttpClient.Builder()
                        .connectTimeout(25, TimeUnit.SECONDS)
                        .readTimeout(25, TimeUnit.SECONDS)
                        .build()

                    val platform = detectPlatform(cleanUrl)

                    if (customRapidKey.isNotBlank()) {
                        val host = "social-download-all-in-one.p.rapidapi.com"
                        val jsonBody = JSONObject().put("url", cleanUrl).toString()
                        val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

                        val request = Request.Builder()
                            .url("https://$host/v1/social/autolink")
                            .post(requestBody)
                            .addHeader("Content-Type", "application/json")
                            .addHeader("x-rapidapi-key", customRapidKey.trim())
                            .addHeader("x-rapidapi-host", host)
                            .build()

                        client.newCall(request).execute().use { response ->
                            val body = response.body?.string() ?: throw Exception("Empty response")
                            if (!response.isSuccessful) throw Exception("RapidAPI Error (${response.code})")
                            val json = JSONObject(body)
                            val title = json.optString("title", "$platform Video").ifBlank { "$platform Video" }
                            val thumb = json.optString("thumbnail", "")
                            val medias = json.optJSONArray("medias")

                            var hdUrl = ""
                            var mp3Url = ""
                            if (medias != null) {
                                for (i in 0 until medias.length()) {
                                    val item = medias.getJSONObject(i)
                                    val ext = item.optString("extension", "").lowercase()
                                    val quality = item.optString("quality", "").lowercase()
                                    val mediaUrl = item.optString("url", "")
                                    if (mediaUrl.isBlank()) continue
                                    if (ext == "mp4" && (hdUrl.isEmpty() || quality.contains("1080") || quality.contains("hd") || quality.contains("no watermark"))) {
                                        hdUrl = mediaUrl
                                    }
                                    if (ext == "mp3" || ext == "m4a") {
                                        mp3Url = mediaUrl
                                    }
                                }
                            }
                            if (hdUrl.isEmpty()) throw Exception("No MP4 stream returned.")
                            return@withContext VideoInfo(
                                title = title,
                                platform = platform,
                                thumbnailUrl = thumb,
                                hdVideoUrl = hdUrl,
                                mp3AudioUrl = mp3Url.ifEmpty { hdUrl }
                            )
                        }
                    }

                    val mirrors = listOf(
                        "https://api.cobalt.tools/",
                        "https://cobalt-api.kwiatekmiki.com/",
                        "https://co.wuk.sh/"
                    )

                    var lastErr = "Server busy"
                    for (endpoint in mirrors) {
                        try {
                            val videoReqJson = JSONObject()
                                .put("url", cleanUrl)
                                .put("videoQuality", "1080")
                                .toString()

                            val videoReq = Request.Builder()
                                .url(endpoint)
                                .post(videoReqJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                                .addHeader("Accept", "application/json")
                                .addHeader("Content-Type", "application/json")
                                .addHeader("User-Agent", "KDownloader/1.4")
                                .build()

                            val videoUrl = client.newCall(videoReq).execute().use { resp ->
                                val txt = resp.body?.string() ?: ""
                                if (!resp.isSuccessful) {
                                    lastErr = "HTTP ${resp.code}"
                                    ""
                                } else {
                                    val j = JSONObject(txt)
                                    j.optString("url", "")
                                }
                            }

                            if (videoUrl.startsWith("http")) {
                                val audioReqJson = JSONObject()
                                    .put("url", cleanUrl)
                                    .put("downloadMode", "audio")
                                    .put("audioFormat", "mp3")
                                    .toString()

                                val audioReq = Request.Builder()
                                    .url(endpoint)
                                    .post(audioReqJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                                    .addHeader("Accept", "application/json")
                                    .addHeader("Content-Type", "application/json")
                                    .build()

                                val audioUrl = try {
                                    client.newCall(audioReq).execute().use { aResp ->
                                        val aTxt = aResp.body?.string() ?: ""
                                        if (aResp.isSuccessful) JSONObject(aTxt).optString("url", videoUrl) else videoUrl
                                    }
                                } catch (_: Exception) {
                                    videoUrl
                                }

                                return@withContext VideoInfo(
                                    title = "$platform Full HD Video",
                                    platform = platform,
                                    thumbnailUrl = "",
                                    hdVideoUrl = videoUrl,
                                    mp3AudioUrl = audioUrl.ifEmpty { videoUrl }
                                )
                            }
                        } catch (e: Exception) {
                            lastErr = e.localizedMessage ?: "Mirror busy"
                        }
                    }
                    throw Exception("Free server busy ($lastErr). Tap the Key icon in the bottom bar to add a free RapidAPI backup key.")
                }
                videoInfo = result
            } catch (e: Exception) {
                errorMessage = e.localizedMessage ?: "Failed to analyze link."
            } finally {
                isFetching = false
            }
        }
    }

    LaunchedEffect(initialSharedUrl) {
        if (initialSharedUrl.isNotBlank()) {
            fetchVideoDetails(initialSharedUrl)
        }
    }

    fun startSystemDownload(downloadUrl: String, fileName: String, mimeType: String) {
        if (downloadUrl.isBlank()) {
            Toast.makeText(context, "Download link unavailable.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val request = DownloadManager.Request(Uri.parse(downloadUrl))
                .setTitle(fileName)
                .setDescription("Downloading via K Downloader")
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(context, "Downloading $fileName to Downloads!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    if (showApiDialog) {
        AlertDialog(
            onDismissRequest = { showApiDialog = false },
            containerColor = Color(0xFF171C2C),
            title = { Text("API Key Configuration", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "K Downloader works out of the box. For 100% uptime on YouTube/FB/TikTok, paste a free RapidAPI 'Social Download All In One' key:",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = tempKeyInput,
                        onValueChange = { tempKeyInput = it },
                        placeholder = { Text("Paste RapidAPI Key...", color = Color(0xFF64748B)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFA855F7),
                            unfocusedBorderColor = Color(0xFF334155)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        customRapidKey = tempKeyInput.trim()
                        prefs.edit().putString("rapidapi_key", customRapidKey).apply()
                        showApiDialog = false
                        Toast.makeText(context, "API Key saved!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6))
                ) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiDialog = false }) {
                    Text("Close", color = Color(0xFF94A3B8))
                }
            }
        )
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            containerColor = Color(0xFF171C2C),
            title = { Text("How to Use K Downloader", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "1. Copy a link from Facebook Reels, TikTok, or YouTube.\n" +
                    "2. Tap the pink clipboard icon to paste & auto-analyze.\n" +
                    "3. Choose Full HD Video (MP4) or Audio (MP3). Files save directly to your Downloads folder.",
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showHelpDialog = false }) {
                    Text("Got it", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0D16))
    ) {
        // Ambient Aurora Mesh Background matching screenshot
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x3814B8A6), Color.Transparent),
                    center = Offset(size.width * 0.15f, size.height * 0.22f),
                    radius = size.width * 0.75f
                ),
                center = Offset(size.width * 0.15f, size.height * 0.22f),
                radius = size.width * 0.75f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x354F46E5), Color.Transparent),
                    center = Offset(size.width * 0.85f, size.height * 0.62f),
                    radius = size.width * 0.8f
                ),
                center = Offset(size.width * 0.85f, size.height * 0.62f),
                radius = size.width * 0.8f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x28EC4899), Color.Transparent),
                    center = Offset(size.width * 0.25f, size.height * 0.88f),
                    radius = size.width * 0.65f
                ),
                center = Offset(size.width * 0.25f, size.height * 0.88f),
                radius = size.width * 0.65f
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. TOP BRAND HEADER
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                            )
                        )
                        .border(1.dp, Color(0x4438BDF8), RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "K",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        style = LocalTextStyle.current.copy(brush = hdCyanGradient)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = "K DOWNLOADER",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "PRO MOBILE v1.4",
                        color = Color(0xFFF43F5E),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.6.sp
                    )
                }
            }

            // 2. CENTER HERO + FROSTED INPUT CARD + RESULT PREVIEW
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Pill Badge: ✨ Fast, Free & No Watermark
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0x261E293B))
                        .border(1.dp, Color(0x3364748B), CircleShape)
                        .padding(horizontal = 16.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = Color(0xFFA5B4FC),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "Fast, Free & No Watermark",
                            color = Color(0xFFCBD5E1),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))

                // Hero Headline
                Text(
                    text = "Download FB Reels &",
                    color = Color.White,
                    fontSize = 27.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "TikTok • YouTube",
                    color = Color.White,
                    fontSize = 27.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(brush = hdCyanGradient, fontWeight = FontWeight.ExtraBold)) {
                            append("in Full HD Quality")
                        }
                    },
                    fontSize = 27.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(26.dp))

                // Frosted Glass Main Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(Color(0x88161B2B))
                        .border(1.dp, Color(0x28FFFFFF), RoundedCornerShape(26.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Platform Chips Row (Cleanly spaced, no edge clipping)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PlatformPill(
                            label = "TikTok",
                            icon = Icons.Rounded.MusicNote,
                            bgColor = Color(0xFF0F131A),
                            iconTint = Color(0xFF22D3EE)
                        )
                        PlatformPill(
                            label = "YouTube",
                            icon = Icons.Rounded.PlayArrow,
                            bgColor = Color(0xFFE11D48),
                            iconTint = Color.White
                        )
                        PlatformPill(
                            label = "FB Reels",
                            icon = Icons.Rounded.VideoLibrary,
                            bgColor = Color(0xFF2563EB),
                            iconTint = Color.White
                        )
                        PlatformPill(
                            label = "Shorts",
                            icon = Icons.Rounded.Bolt,
                            bgColor = Color(0xFFF97316),
                            iconTint = Color.White
                        )
                    }

                    // Dark Recessed Input Box with Link Icon + Pink Paste Clipboard Icon
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xCC0D111C))
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Link,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            if (urlInput.isEmpty()) {
                                Text(
                                    text = "Paste FB Reels, TikTok, or YT link...",
                                    color = Color(0xFF64748B),
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            androidx.compose.foundation.text.BasicTextField(
                                value = urlInput,
                                onValueChange = { urlInput = it },
                                singleLine = true,
                                textStyle = LocalTextStyle.current.copy(
                                    color = Color.White,
                                    fontSize = 14.sp
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        if (urlInput.isNotEmpty()) {
                            IconButton(
                                onClick = { urlInput = ""; videoInfo = null; errorMessage = null },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Clear",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = {
                                val pasted = clipboardManager.getText()?.text ?: ""
                                if (pasted.isNotBlank()) {
                                    urlInput = pasted
                                    fetchVideoDetails(pasted)
                                } else {
                                    Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ContentPaste,
                                contentDescription = "Paste Link",
                                tint = Color(0xFFEC4899),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Full-Width Analyze Link -> Gradient Button
                    Button(
                        onClick = { fetchVideoDetails(urlInput) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(analyzeGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isFetching) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        strokeWidth = 2.5.dp,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        text = "Analyzing Link...",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.Search,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(19.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Analyze Link →",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Error Banner
                errorMessage?.let { msg ->
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = msg,
                        color = Color(0xFFFCA5A5),
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x667F1D1D))
                            .border(1.dp, Color(0x55EF4444), RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    )
                }

                // Video Result & Download Card
                AnimatedVisibility(visible = videoInfo != null) {
                    videoInfo?.let { info ->
                        Column(
                            modifier = Modifier
                                .padding(top = 16.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(22.dp))
                                .background(Color(0x99161B2B))
                                .border(1.dp, Color(0x3338BDF8), RoundedCornerShape(22.dp))
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (info.thumbnailUrl.isNotBlank()) {
                                AsyncImage(
                                    model = info.thumbnailUrl,
                                    contentDescription = "Preview",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(155.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0x3338BDF8))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = info.platform,
                                        color = Color(0xFF38BDF8),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = info.title,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Button(
                                onClick = {
                                    val fileName = "KDownloader_HD_${System.currentTimeMillis()}.mp4"
                                    startSystemDownload(info.hdVideoUrl, fileName, "video/mp4")
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                contentPadding = PaddingValues()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(analyzeGradient),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.Hd, contentDescription = null, tint = Color.White)
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            "Download Full HD Video (MP4)",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    val fileName = "KDownloader_Audio_${System.currentTimeMillis()}.mp3"
                                    startSystemDownload(info.mp3AudioUrl, fileName, "audio/mpeg")
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8))
                            ) {
                                Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color(0xFF38BDF8))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Download Audio Only (MP3)",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            // 3. BOTTOM FROSTED DOCK BAR (Matching 4-icon pill bar in screenshot)
            Row(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0x66161B2B))
                    .border(1.dp, Color(0x22FFFFFF), CircleShape)
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                DockIcon(
                    icon = Icons.Rounded.Bolt,
                    tint = Color(0xFF38BDF8),
                    bg = Color(0x2238BDF8),
                    onClick = { Toast.makeText(context, "Ultra-Fast HD Mode Active", Toast.LENGTH_SHORT).show() }
                )
                Box(Modifier.width(1.dp).height(18.dp).background(Color(0x22FFFFFF)))
                DockIcon(
                    icon = Icons.Rounded.Refresh,
                    tint = Color(0xFFF43F5E),
                    bg = Color.Transparent,
                    onClick = {
                        urlInput = ""
                        videoInfo = null
                        errorMessage = null
                        Toast.makeText(context, "Cleared", Toast.LENGTH_SHORT).show()
                    }
                )
                Box(Modifier.width(1.dp).height(18.dp).background(Color(0x22FFFFFF)))
                DockIcon(
                    icon = Icons.Rounded.Key,
                    tint = Color(0xFF38BDF8),
                    bg = Color(0x2238BDF8),
                    onClick = {
                        tempKeyInput = customRapidKey
                        showApiDialog = true
                    }
                )
                Box(Modifier.width(1.dp).height(18.dp).background(Color(0x22FFFFFF)))
                DockIcon(
                    icon = Icons.Rounded.HelpOutline,
                    tint = Color(0xFF4ADE80),
                    bg = Color.Transparent,
                    onClick = { showHelpDialog = true }
                )
            }
        }
    }
}

@Composable
fun PlatformPill(
    label: String,
    icon: ImageVector,
    bgColor: Color,
    iconTint: Color
) {
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(bgColor)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(15.dp)
        )
        Text(
            text = label,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DockIcon(
    icon: ImageVector,
    tint: Color,
    bg: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(bg)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(18.dp)
        )
    }
}
