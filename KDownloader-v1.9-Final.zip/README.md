# K Downloader v1.9 — Copyright by : YEOM BROS
- Fixed Kotlin compilation error (removed invalid androidx.compose.foundation.Icon import)
- Includes Telegram Support logo opening https://t.me/Mr_BROS_Kh
- Includes live % download progress, Instagram/Pinterest/Douyin/Kuaishou/TikTok/FB/YouTube support, and hidden 5-tap Admin Panel (PIN: 1688)
