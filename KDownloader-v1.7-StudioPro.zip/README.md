# K Downloader v1.7 — Copyright by : YEOM BROS
- Fixed Instagram Reels & Posts links (strips tracking parameters like ?lqvp=... and adds direct embed extraction fallback)
- Removed visible ADMIN badge from the top bar (hidden 5-tap trigger on the K logo with PIN 1688)
- Refined Studio Pro UI with live % download progress and Instagram, Pinterest, Douyin, Kuaishou, TikTok, FB Reels, and YouTube support
