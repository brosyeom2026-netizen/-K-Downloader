package com.kdownloader.pro

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class QualityOption(
    val label: String,
    val url: String,
    val extension: String,
    val isAudio: Boolean
)

data class VideoInfo(
    val title: String,
    val platform: String,
    val duration: String,
    val thumbnailUrl: String,
    val qualities: List<QualityOption>,
    val hdVideoUrl: String,
    val mp3AudioUrl: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedText = if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            extractFirstUrl(intent.getStringExtra(Intent.EXTRA_TEXT) ?: "")
        } else {
            ""
        }

        setContent {
            KDownloaderApp(initialSharedUrl = sharedText)
        }
    }

    private fun extractFirstUrl(text: String): String {
        val matcher = Pattern.compile("(https?://\\S+)").matcher(text)
        return if (matcher.find()) matcher.group(1) ?: text else text
    }
}

object AdminSecurity {
    private const val SALT = "YEOMBROS_KDOWNLOADER_2026_PRO"

    fun getDeviceRequestId(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "UNKNOWN_DEVICE"
        val hash = sha256("$androidId:$SALT").take(8).uppercase()
        return "KD-${hash.substring(0, 4)}-${hash.substring(4, 8)}"
    }

    fun generateApprovalCode(requestId: String): String {
        val cleanId = requestId.trim().uppercase()
        val hash = sha256("$cleanId:APPROVED:$SALT").take(8).uppercase()
        return "YB-${hash.substring(0, 4)}-${hash.substring(4, 8)}"
    }

    fun verifyApprovalCode(requestId: String, inputCode: String): Boolean {
        val expected = generateApprovalCode(requestId)
        return inputCode.trim().uppercase() == expected
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

@Composable
fun KDownloaderApp(initialSharedUrl: String = "") {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val prefs = remember {
        context.getSharedPreferences("kdownloader_v7_prefs", Context.MODE_PRIVATE)
    }

    // Admin Control State (Hidden behind 5-tap on K logo — NO Admin button shown on top bar!)
    val myRequestId = remember { AdminSecurity.getDeviceRequestId(context) }
    var isAppUnlocked by remember {
        mutableStateOf(prefs.getBoolean("app_unlocked", false))
    }
    var lockScreenEnabled by remember {
        mutableStateOf(prefs.getBoolean("lock_screen_enabled", true))
    }
    var adminPin by remember {
        mutableStateOf(prefs.getString("admin_pin", "1688") ?: "1688")
    }
    var activationInput by remember { mutableStateOf("") }
    var activationError by remember { mutableStateOf<String?>(null) }

    var logoTapCount by remember { mutableIntStateOf(0) }
    var showAdminPinDialog by remember { mutableStateOf(false) }
    var showAdminDashboard by remember { mutableStateOf(false) }
    var pinEntry by remember { mutableStateOf("") }
    var adminTargetRequestId by remember { mutableStateOf(myRequestId) }
    var adminGeneratedCode by remember { mutableStateOf(AdminSecurity.generateApprovalCode(myRequestId)) }
    var newPinInput by remember { mutableStateOf("") }

    // API Key Configuration
    val defaultKey = "bc1e96d787msh3ea6dd2adf4316ep1df0dajsn5acd83f54e0d"
    var customRapidKey by remember {
        mutableStateOf(prefs.getString("rapidapi_key", defaultKey) ?: defaultKey)
    }
    var showApiDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var tempKeyInput by remember { mutableStateOf(customRapidKey) }

    // Fetch & Live Percentage Download State
    var urlInput by remember { mutableStateOf(initialSharedUrl) }
    var isFetching by remember { mutableStateOf(false) }
    var videoInfo by remember { mutableStateOf<VideoInfo?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var isDownloading by remember { mutableStateOf(false) }
    var downloadProgress by remember { mutableIntStateOf(0) }
    var downloadStatusText by remember { mutableStateOf("") }
    var downloadedSizeText by remember { mutableStateOf("") }

    val primaryButtonGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF4F46E5), Color(0xFF9333EA), Color(0xFFDB2777))
    )

    val brandGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF38BDF8), Color(0xFF818CF8), Color(0xFFE879F9))
    )

    fun detectPlatform(url: String): String {
        val lower = url.lowercase()
        return when {
            lower.contains("instagram.com") || lower.contains("instagr.am") -> "Instagram"
            lower.contains("pinterest.com") || lower.contains("pin.it") -> "Pinterest"
            lower.contains("tiktok.com") -> "TikTok"
            lower.contains("facebook.com") || lower.contains("fb.watch") -> "Facebook Reels"
            lower.contains("youtu.be") || lower.contains("youtube.com") -> {
                if (lower.contains("/shorts/")) "YouTube Shorts" else "YouTube HD"
            }
            lower.contains("douyin.com") -> "Douyin"
            lower.contains("kuaishou.com") || lower.contains("chenzhongtech.com") -> "Kuaishou"
            else -> "Social Media"
        }
    }

    // Normalizes Instagram /reel/, /reels/, /p/, /tv/ URLs and strips tracking query params (?lqvp=..., ?igsh=...)
    fun normalizeMediaUrl(raw: String): String {
        val matcher = Pattern.compile("(https?://\\S+)").matcher(raw.trim())
        var extracted = if (matcher.find()) matcher.group(1) ?: raw.trim() else raw.trim()
        extracted = extracted.trimEnd(',', '.', ')', ']', '"', '\'')

        val lower = extracted.lowercase()
        if (lower.contains("instagram.com")) {
            val baseNoQuery = extracted.substringBefore("?")
            val igRegex = Pattern.compile("https?://(?:www\\.)?instagram\\.com/(?:[^/]+/)?(reel|reels|p|tv)/([A-Za-z0-9_-]+)")
            val m = igRegex.matcher(baseNoQuery)
            if (m.find()) {
                val kind = if (m.group(1) == "reels") "reel" else m.group(1)
                val code = m.group(2)
                return "https://www.instagram.com/$kind/$code/"
            }
            return if (baseNoQuery.endsWith("/")) baseNoQuery else "$baseNoQuery/"
        }
        return extracted
    }

    fun formatDuration(sec: Int): String {
        if (sec <= 0) return ""
        val m = sec / 60
        val s = sec % 60
        return String.format("%d:%02d", m, s)
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 MB"
        val mb = bytes / (1024.0 * 1024.0)
        return String.format("%.1f MB", mb)
    }

    // Direct HTML/JSON fallback for Instagram Reels/Posts when RapidAPI/Cobalt mirrors are busy
    fun extractInstagramDirectFallback(client: OkHttpClient, igUrl: String): VideoInfo? {
        val userAgents = listOf(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        )
        for (ua in userAgents) {
            try {
                val embedUrl = if (igUrl.endsWith("/")) "${igUrl}embed/captioned/" else "$igUrl/embed/captioned/"
                val req = Request.Builder()
                    .url(embedUrl)
                    .get()
                    .addHeader("User-Agent", ua)
                    .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .addHeader("Accept-Language", "en-US,en;q=0.9")
                    .build()

                val html = client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) resp.body?.string() ?: "" else ""
                }
                if (html.isBlank()) continue

                // Look for video_url in embedded JSON or <video src="...">
                val patterns = listOf(
                    Pattern.compile("\"video_url\"\\s*:\\s*\"(https:[^\"]+)\""),
                    Pattern.compile("property=\"og:video\"\\s+content=\"(https:[^\"]+)\""),
                    Pattern.compile("<video[^>]+src=\"(https:[^\"]+)\"")
                )
                for (pat in patterns) {
                    val m = pat.matcher(html)
                    if (m.find()) {
                        val rawVideo = m.group(1) ?: continue
                        val cleanVideoUrl = rawVideo
                            .replace("\\u0026", "&")
                            .replace("\\/", "/")
                            .replace("&amp;", "&")
                        if (cleanVideoUrl.startsWith("http")) {
                            var thumbUrl = ""
                            val thumbMatcher = Pattern.compile("property=\"og:image\"\\s+content=\"(https:[^\"]+)\"").matcher(html)
                            if (thumbMatcher.find()) {
                                thumbUrl = (thumbMatcher.group(1) ?: "").replace("&amp;", "&")
                            }
                            return VideoInfo(
                                title = "Instagram Reel HD Video",
                                platform = "Instagram",
                                duration = "",
                                thumbnailUrl = thumbUrl,
                                qualities = listOf(QualityOption("INSTAGRAM HD (MP4)", cleanVideoUrl, "mp4", false)),
                                hdVideoUrl = cleanVideoUrl,
                                mp3AudioUrl = cleanVideoUrl
                            )
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    fun fetchVideoDetails(rawLink: String) {
        val cleanUrl = normalizeMediaUrl(rawLink)
        if (cleanUrl.isEmpty() || !cleanUrl.startsWith("http")) {
            errorMessage = "Please paste a valid video link first."
            return
        }
        urlInput = cleanUrl
        errorMessage = null
        videoInfo = null
        isFetching = true

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val client = OkHttpClient.Builder()
                        .connectTimeout(25, TimeUnit.SECONDS)
                        .readTimeout(25, TimeUnit.SECONDS)
                        .followRedirects(true)
                        .build()

                    val platform = detectPlatform(cleanUrl)
                    val activeKey = customRapidKey.trim()
                    var lastApiError = ""

                    // 1. Primary Universal Extractor: RapidAPI Social Download All In One
                    if (activeKey.isNotBlank()) {
                        try {
                            val host = "social-download-all-in-one.p.rapidapi.com"
                            val jsonBody = JSONObject().put("url", cleanUrl).toString()
                            val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

                            val request = Request.Builder()
                                .url("https://$host/v1/social/autolink")
                                .post(requestBody)
                                .addHeader("Content-Type", "application/json")
                                .addHeader("x-rapidapi-key", activeKey)
                                .addHeader("x-rapidapi-host", host)
                                .build()

                            client.newCall(request).execute().use { response ->
                                val body = response.body?.string() ?: ""
                                if (response.isSuccessful && body.isNotBlank()) {
                                    val json = JSONObject(body)
                                    val title = json.optString("title", "$platform Media").ifBlank { "$platform Media" }
                                    val thumb = json.optString("thumbnail", "")
                                    val durationSec = json.optInt("duration", 0)
                                    val medias = json.optJSONArray("medias")

                                    val qualityList = mutableListOf<QualityOption>()
                                    var hdUrl = ""
                                    var mp3Url = ""

                                    if (medias != null) {
                                        for (i in 0 until medias.length()) {
                                            val item = medias.getJSONObject(i)
                                            val ext = item.optString("extension", "mp4").lowercase()
                                            val quality = item.optString("quality", "HD").ifBlank { "HD" }
                                            val mediaUrl = item.optString("url", "")
                                            if (mediaUrl.isBlank() || !mediaUrl.startsWith("http")) continue

                                            val isAudio = ext == "mp3" || ext == "m4a" || quality.lowercase().contains("audio")
                                            val cleanExt = when {
                                                isAudio -> "mp3"
                                                ext == "jpg" || ext == "jpeg" || ext == "png" || ext == "webp" -> ext
                                                else -> "mp4"
                                            }
                                            qualityList.add(
                                                QualityOption(
                                                    label = "${quality.uppercase()} (${cleanExt.uppercase()})",
                                                    url = mediaUrl,
                                                    extension = cleanExt,
                                                    isAudio = isAudio
                                                )
                                            )

                                            if (!isAudio && (hdUrl.isEmpty() || quality.lowercase().contains("1080") || quality.lowercase().contains("hd") || quality.lowercase().contains("no watermark"))) {
                                                hdUrl = mediaUrl
                                            }
                                            if (isAudio && mp3Url.isEmpty()) {
                                                mp3Url = mediaUrl
                                            }
                                        }
                                    }

                                    if (hdUrl.isNotEmpty()) {
                                        return@withContext VideoInfo(
                                            title = title,
                                            platform = platform,
                                            duration = formatDuration(durationSec),
                                            thumbnailUrl = thumb,
                                            qualities = qualityList,
                                            hdVideoUrl = hdUrl,
                                            mp3AudioUrl = mp3Url.ifEmpty { hdUrl }
                                        )
                                    }
                                } else {
                                    lastApiError = "API HTTP ${response.code}"
                                }
                            }
                        } catch (e: Exception) {
                            lastApiError = e.localizedMessage ?: "API timeout"
                        }
                    }

                    // 2. Dedicated Instagram Embed/Direct Fallback (Handles /reel/DgNdqHQCpC6/ cleanly!)
                    if (cleanUrl.lowercase().contains("instagram.com")) {
                        val igResult = extractInstagramDirectFallback(client, cleanUrl)
                        if (igResult != null) {
                            return@withContext igResult
                        }
                    }

                    // 3. Dedicated Free TikTok & Douyin No-Watermark Engine (TikWM)
                    if (cleanUrl.lowercase().contains("tiktok.com") || cleanUrl.lowercase().contains("douyin.com")) {
                        try {
                            val encoded = URLEncoder.encode(cleanUrl, "UTF-8")
                            val tikReq = Request.Builder()
                                .url("https://www.tikwm.com/api/?url=$encoded&hd=1")
                                .get()
                                .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                                .build()

                            client.newCall(tikReq).execute().use { resp ->
                                val txt = resp.body?.string() ?: ""
                                if (resp.isSuccessful && txt.isNotBlank()) {
                                    val root = JSONObject(txt)
                                    if (root.optInt("code", -1) == 0) {
                                        val data = root.getJSONObject("data")
                                        val title = data.optString("title", "$platform HD Video").ifBlank { "$platform HD Video" }
                                        val cover = data.optString("cover", "")
                                        val dur = data.optInt("duration", 0)
                                        val hdPlay = data.optString("hdplay", "").ifBlank { data.optString("play", "") }
                                        val sdPlay = data.optString("play", hdPlay)
                                        val music = data.optString("music", hdPlay)

                                        if (hdPlay.startsWith("http")) {
                                            val opts = mutableListOf(
                                                QualityOption("1080P NO WATERMARK (MP4)", hdPlay, "mp4", false)
                                            )
                                            if (sdPlay != hdPlay && sdPlay.startsWith("http")) {
                                                opts.add(QualityOption("STANDARD NO WATERMARK (MP4)", sdPlay, "mp4", false))
                                            }
                                            if (music.startsWith("http")) {
                                                opts.add(QualityOption("ORIGINAL SOUND (MP3)", music, "mp3", true))
                                            }
                                            return@withContext VideoInfo(
                                                title = title,
                                                platform = platform,
                                                duration = formatDuration(dur),
                                                thumbnailUrl = cover,
                                                qualities = opts,
                                                hdVideoUrl = hdPlay,
                                                mp3AudioUrl = music.ifEmpty { hdPlay }
                                            )
                                        }
                                    }
                                }
                            }
                        } catch (_: Exception) {
                        }
                    }

                    // 4. Multi-Mirror Cobalt Fallback for Instagram, Pinterest, YouTube, FB
                    val mirrors = listOf(
                        "https://api.cobalt.tools/",
                        "https://cobalt-api.kwiatekmiki.com/"
                    )
                    for (endpoint in mirrors) {
                        try {
                            val videoReqJson = JSONObject()
                                .put("url", cleanUrl)
                                .put("videoQuality", "1080")
                                .toString()

                            val videoReq = Request.Builder()
                                .url(endpoint)
                                .post(videoReqJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                                .addHeader("Accept", "application/json")
                                .addHeader("Content-Type", "application/json")
                                .build()

                            val videoUrl = client.newCall(videoReq).execute().use { resp ->
                                val txt = resp.body?.string() ?: ""
                                if (resp.isSuccessful) JSONObject(txt).optString("url", "") else ""
                            }

                            if (videoUrl.startsWith("http")) {
                                return@withContext VideoInfo(
                                    title = "$platform Full HD Video",
                                    platform = platform,
                                    duration = "",
                                    thumbnailUrl = "",
                                    qualities = listOf(QualityOption("FULL HD (MP4)", videoUrl, "mp4", false)),
                                    hdVideoUrl = videoUrl,
                                    mp3AudioUrl = videoUrl
                                )
                            }
                        } catch (_: Exception) {
                        }
                    }

                    val hint = if (lastApiError == "API HTTP 403") {
                        "RapidAPI key needs free subscription to 'Social Download All In One' on RapidAPI, or post may be private."
                    } else {
                        "Post may be private or servers are busy. Tap the Key icon below to check your RapidAPI key."
                    }
                    throw Exception("Could not extract $platform link. $hint")
                }
                videoInfo = result
            } catch (e: Exception) {
                errorMessage = e.localizedMessage ?: "Failed to analyze link."
            } finally {
                isFetching = false
            }
        }
    }

    LaunchedEffect(initialSharedUrl) {
        if (initialSharedUrl.isNotBlank() && (isAppUnlocked || !lockScreenEnabled)) {
            fetchVideoDetails(initialSharedUrl)
        }
    }

    // Real-Time Streaming Download with Live Percentage (0% -> 100%)
    fun startRealTimeDownload(downloadUrl: String, fileName: String, mimeType: String) {
        if (downloadUrl.isBlank()) {
            Toast.makeText(context, "Download link unavailable.", Toast.LENGTH_SHORT).show()
            return
        }
        if (isDownloading) {
            Toast.makeText(context, "A download is already in progress...", Toast.LENGTH_SHORT).show()
            return
        }

        isDownloading = true
        downloadProgress = 0
        downloadStatusText = "Connecting to media server..."
        downloadedSizeText = ""

        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val client = OkHttpClient.Builder()
                        .connectTimeout(30, TimeUnit.SECONDS)
                        .readTimeout(60, TimeUnit.SECONDS)
                        .followRedirects(true)
                        .build()

                    val request = Request.Builder()
                        .url(downloadUrl)
                        .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                        .addHeader("Referer", "https://www.instagram.com/")
                        .build()

                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) {
                            throw Exception("Server returned HTTP ${response.code}")
                        }
                        val body = response.body ?: throw Exception("Empty media stream")
                        val totalBytes = body.contentLength()

                        var outputStream: OutputStream? = null
                        var savedFilePath: String? = null

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            val values = ContentValues().apply {
                                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KDownloader")
                            }
                            val resolver = context.contentResolver
                            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                                ?: throw Exception("Could not create file in Downloads")
                            outputStream = resolver.openOutputStream(uri)
                        } else {
                            val dir = File(
                                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                                "KDownloader"
                            )
                            if (!dir.exists()) dir.mkdirs()
                            val outFile = File(dir, fileName)
                            savedFilePath = outFile.absolutePath
                            outputStream = FileOutputStream(outFile)
                        }

                        outputStream?.use { out ->
                            body.byteStream().use { input ->
                                val buffer = ByteArray(8192)
                                var bytesRead: Int
                                var totalRead = 0L
                                var lastPercent = -1

                                while (input.read(buffer).also { bytesRead = it } != -1) {
                                    out.write(buffer, 0, bytesRead)
                                    totalRead += bytesRead

                                    val percent = if (totalBytes > 0) {
                                        ((totalRead * 100) / totalBytes).toInt().coerceIn(0, 100)
                                    } else {
                                        ((totalRead / (1024 * 60)) % 95).toInt()
                                    }

                                    if (percent != lastPercent) {
                                        lastPercent = percent
                                        val sizeStr = if (totalBytes > 0) {
                                            "${formatBytes(totalRead)} / ${formatBytes(totalBytes)}"
                                        } else {
                                            formatBytes(totalRead)
                                        }
                                        withContext(Dispatchers.Main) {
                                            downloadProgress = percent
                                            downloadStatusText = "Downloading... $percent%"
                                            downloadedSizeText = sizeStr
                                        }
                                    }
                                }
                                out.flush()
                            }
                        }

                        if (savedFilePath != null) {
                            MediaScannerConnection.scanFile(context, arrayOf(savedFilePath), arrayOf(mimeType), null)
                        }

                        withContext(Dispatchers.Main) {
                            downloadProgress = 100
                            downloadStatusText = "Completed 100% — Saved to Downloads/KDownloader"
                        }
                    }
                }
                Toast.makeText(context, "Saved $fileName (100%)!", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    downloadStatusText = "Download error: ${e.localizedMessage}"
                }
                Toast.makeText(context, "Download failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            } finally {
                isDownloading = false
            }
        }
    }

    // Hidden 5-Tap Admin PIN Prompt Dialog
    if (showAdminPinDialog) {
        AlertDialog(
            onDismissRequest = { showAdminPinDialog = false; pinEntry = "" },
            containerColor = Color(0xFF141824),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Security, contentDescription = null, tint = Color(0xFF38BDF8))
                    Spacer(Modifier.width(8.dp))
                    Text("YEOM BROS Admin", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Enter Admin PIN to access App Controls:",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = pinEntry,
                        onValueChange = { pinEntry = it },
                        placeholder = { Text("Admin PIN", color = Color(0xFF64748B)) },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF334155)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinEntry.trim() == adminPin) {
                            showAdminPinDialog = false
                            pinEntry = ""
                            showAdminDashboard = true
                        } else {
                            Toast.makeText(context, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                ) {
                    Text("Unlock Panel", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdminPinDialog = false; pinEntry = "" }) {
                    Text("Cancel", color = Color(0xFF94A3B8))
                }
            }
        )
    }

    // Full Admin Control Dashboard Modal
    if (showAdminDashboard) {
        AlertDialog(
            onDismissRequest = { showAdminDashboard = false },
            containerColor = Color(0xFF121726),
            title = {
                Column {
                    Text("ADMIN CONTROL PANEL", color = Color(0xFF38BDF8), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text("Copyright by : YEOM BROS", color = Color(0xFF94A3B8), fontSize = 11.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E293B))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Require User Activation Lock", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Lock app until Admin Approval Code is entered", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        }
                        Switch(
                            checked = lockScreenEnabled,
                            onCheckedChange = { enabled ->
                                lockScreenEnabled = enabled
                                prefs.edit().putBoolean("lock_screen_enabled", enabled).apply()
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                isAppUnlocked = true
                                prefs.edit().putBoolean("app_unlocked", true).apply()
                                Toast.makeText(context, "Device Unlocked!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                        ) {
                            Text("Unlock Device", fontSize = 12.sp, color = Color.White)
                        }
                        OutlinedButton(
                            onClick = {
                                isAppUnlocked = false
                                prefs.edit().putBoolean("app_unlocked", false).apply()
                                Toast.makeText(context, "Device Locked!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Lock Device", fontSize = 12.sp, color = Color(0xFFF87171))
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E293B))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("User Approval Code Generator", color = Color(0xFFA855F7), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        OutlinedTextField(
                            value = adminTargetRequestId,
                            onValueChange = {
                                adminTargetRequestId = it
                                adminGeneratedCode = AdminSecurity.generateApprovalCode(it)
                            },
                            label = { Text("Enter User Request ID", fontSize = 11.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F172A))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = adminGeneratedCode,
                                color = Color(0xFF4ADE80),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp
                            )
                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(adminGeneratedCode))
                                    Toast.makeText(context, "Approval Code Copied!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E293B))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Global RapidAPI Key", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        OutlinedTextField(
                            value = tempKeyInput,
                            onValueChange = { tempKeyInput = it },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        Button(
                            onClick = {
                                customRapidKey = tempKeyInput.trim()
                                prefs.edit().putString("rapidapi_key", customRapidKey).apply()
                                Toast.makeText(context, "API Key Updated!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                        ) {
                            Text("Save API Key", color = Color.White, fontSize = 12.sp)
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E293B))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Change Admin PIN (Current: $adminPin)", color = Color(0xFFFBBF24), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newPinInput,
                                onValueChange = { newPinInput = it },
                                placeholder = { Text("New PIN", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                            Button(
                                onClick = {
                                    if (newPinInput.trim().length >= 4) {
                                        adminPin = newPinInput.trim()
                                        prefs.edit().putString("admin_pin", adminPin).apply()
                                        newPinInput = ""
                                        Toast.makeText(context, "Admin PIN Changed!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "PIN must be at least 4 digits", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) {
                                Text("Set", color = Color.White)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAdminDashboard = false }) {
                    Text("Close", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    if (showApiDialog) {
        AlertDialog(
            onDismissRequest = { showApiDialog = false },
            containerColor = Color(0xFF141824),
            title = { Text("API Key Settings", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Update your RapidAPI 'Social Download All In One' key:",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = tempKeyInput,
                        onValueChange = { tempKeyInput = it },
                        placeholder = { Text("Paste RapidAPI Key...", color = Color(0xFF64748B)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFA855F7),
                            unfocusedBorderColor = Color(0xFF334155)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        customRapidKey = tempKeyInput.trim()
                        prefs.edit().putString("rapidapi_key", customRapidKey).apply()
                        showApiDialog = false
                        Toast.makeText(context, "API Key saved!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                ) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiDialog = false }) {
                    Text("Close", color = Color(0xFF94A3B8))
                }
            }
        )
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            containerColor = Color(0xFF141824),
            title = { Text("K Downloader Pro Guide", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "• Supported: Instagram Reels/Posts, Pinterest, Douyin, Kuaishou, TikTok, Facebook Reels, YouTube & Shorts.\n" +
                    "• One-Tap Paste: Copy any link and tap the clipboard button inside the input box.\n" +
                    "• Live Progress: Real-time % and MB counter appear while saving to Downloads/KDownloader.",
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showHelpDialog = false }) {
                    Text("Got it", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070A12))
    ) {
        // Refined Studio Dark Ambient Lighting
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x2A0EA5E9), Color.Transparent),
                    center = Offset(size.width * 0.12f, size.height * 0.16f),
                    radius = size.width * 0.72f
                ),
                center = Offset(size.width * 0.12f, size.height * 0.16f),
                radius = size.width * 0.72f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x286366F1), Color.Transparent),
                    center = Offset(size.width * 0.88f, size.height * 0.55f),
                    radius = size.width * 0.78f
                ),
                center = Offset(size.width * 0.88f, size.height * 0.55f),
                radius = size.width * 0.78f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x20DB2777), Color.Transparent),
                    center = Offset(size.width * 0.25f, size.height * 0.90f),
                    radius = size.width * 0.65f
                ),
                center = Offset(size.width * 0.25f, size.height * 0.90f),
                radius = size.width * 0.65f
            )
        }

        // USER ACTIVATION LOCK SCREEN
        if (lockScreenEnabled && !isAppUnlocked) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Clean Brand Header (Hidden 5-tap trigger on logo)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            logoTapCount++
                            if (logoTapCount >= 5) {
                                logoTapCount = 0
                                showAdminPinDialog = true
                            }
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A))))
                            .border(1.dp, Color(0x4438BDF8), RoundedCornerShape(13.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "K",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            style = LocalTextStyle.current.copy(brush = brandGradient)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("K DOWNLOADER", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp)
                        Text("PRO STUDIO • v1.7", color = Color(0xFF38BDF8), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                    }
                }

                // Activation Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(Color(0xAA111625))
                        .border(1.dp, Color(0x28FFFFFF), RoundedCornerShape(26.dp))
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color(0x226366F1)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(28.dp))
                    }

                    Text(
                        text = "License Activation",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Share your Request ID with YEOM BROS to receive your device Approval Code.",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xCC0A0E17))
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(14.dp))
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("DEVICE REQUEST ID", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(myRequestId, color = Color(0xFF38BDF8), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(myRequestId))
                                Toast.makeText(context, "Request ID copied!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy ID", tint = Color(0xFFE879F9))
                        }
                    }

                    OutlinedTextField(
                        value = activationInput,
                        onValueChange = { activationInput = it; activationError = null },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Enter Approval Code (YB-XXXX-XXXX)", color = Color(0xFF64748B), fontSize = 13.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF818CF8),
                            unfocusedBorderColor = Color(0xFF334155)
                        )
                    )

                    activationError?.let { err ->
                        Text(err, color = Color(0xFFF87171), fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            if (AdminSecurity.verifyApprovalCode(myRequestId, activationInput)) {
                                isAppUnlocked = true
                                prefs.edit().putBoolean("app_unlocked", true).apply()
                                Toast.makeText(context, "Activated! Welcome to K Downloader Pro.", Toast.LENGTH_LONG).show()
                            } else {
                                activationError = "Invalid Approval Code. Please check and try again."
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(primaryButtonGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Activate License", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                    }
                }

                Text(
                    text = "Copyright by : YEOM BROS",
                    color = Color(0xFF64748B),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.6.sp
                )
            }
        } else {
            // CLEAN, PROFESSIONAL MAIN APP SCREEN (No Admin button on top!)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Clean Studio Header (5 taps on logo opens hidden Admin Panel)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            logoTapCount++
                            if (logoTapCount >= 5) {
                                logoTapCount = 0
                                showAdminPinDialog = true
                            }
                        },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A))))
                                .border(1.dp, Color(0x3338BDF8), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "K",
                                fontSize = 21.sp,
                                fontWeight = FontWeight.Black,
                                style = LocalTextStyle.current.copy(brush = brandGradient)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "K DOWNLOADER",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "PRO MEDIA SAVER • v1.7",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.6.sp
                            )
                        }
                    }

                    // Clean Subtle Quality Pill (No Admin badge)
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0x1A38BDF8))
                            .border(1.dp, Color(0x3338BDF8), CircleShape)
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "4K / HD READY",
                            color = Color(0xFF38BDF8),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Center Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // Clean Subtitle Pill
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0x221E293B))
                            .border(1.dp, Color(0x28FFFFFF), CircleShape)
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "Ultra-Fast • No Watermark • MP4 & MP3",
                                color = Color(0xFFCBD5E1),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    Text(
                        text = "Save Social Videos",
                        color = Color.White,
                        fontSize = 27.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = buildAnnotatedString {
                            withStyle(SpanStyle(brush = brandGradient, fontWeight = FontWeight.ExtraBold)) {
                                append("in Original Full HD")
                            }
                        },
                        fontSize = 27.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(Modifier.height(20.dp))

                    // Sleek Studio Glass Card
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0x99111625))
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(24.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Platform Pills Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PlatformPill("Instagram", Icons.Rounded.CameraAlt, Color(0xFFD62976), Color.White)
                            PlatformPill("Pinterest", Icons.Rounded.PushPin, Color(0xFFE60023), Color.White)
                            PlatformPill("Douyin", Icons.Rounded.Bolt, Color(0xFF161B26), Color(0xFF22D3EE))
                            PlatformPill("Kuaishou", Icons.Rounded.Movie, Color(0xFFFF4906), Color.White)
                            PlatformPill("TikTok", Icons.Rounded.MusicNote, Color(0xFF161B26), Color(0xFFF43F5E))
                            PlatformPill("FB Reels", Icons.Rounded.VideoLibrary, Color(0xFF2563EB), Color.White)
                            PlatformPill("YouTube", Icons.Rounded.PlayArrow, Color(0xFFDC2626), Color.White)
                        }

                        // Clean Dark Input Field
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .clip(RoundedCornerShape(15.dp))
                                .background(Color(0xDD0A0E17))
                                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(15.dp))
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Link,
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                if (urlInput.isEmpty()) {
                                    Text(
                                        text = "Paste Instagram, TikTok, YT, FB link...",
                                        color = Color(0xFF64748B),
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                androidx.compose.foundation.text.BasicTextField(
                                    value = urlInput,
                                    onValueChange = { urlInput = it },
                                    singleLine = true,
                                    textStyle = LocalTextStyle.current.copy(
                                        color = Color.White,
                                        fontSize = 14.sp
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            if (urlInput.isNotEmpty()) {
                                IconButton(
                                    onClick = { urlInput = ""; videoInfo = null; errorMessage = null },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Clear",
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    val pasted = clipboardManager.getText()?.text ?: ""
                                    if (pasted.isNotBlank()) {
                                        urlInput = pasted
                                        fetchVideoDetails(pasted)
                                    } else {
                                        Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ContentPaste,
                                    contentDescription = "Paste Link",
                                    tint = Color(0xFFE879F9),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Primary Action Button
                        Button(
                            onClick = { fetchVideoDetails(urlInput) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            contentPadding = PaddingValues()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(primaryButtonGradient),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isFetching) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CircularProgressIndicator(
                                            color = Color.White,
                                            strokeWidth = 2.5.dp,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(Modifier.width(10.dp))
                                        Text(
                                            text = "Extracting Media...",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                    }
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.DownloadForOffline,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = "Fetch & Download",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Live % Download Progress Card
                    AnimatedVisibility(visible = isDownloading || downloadProgress > 0) {
                        Column(
                            modifier = Modifier
                                .padding(top = 14.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0xAA111625))
                                .border(1.dp, Color(0x4438BDF8), RoundedCornerShape(18.dp))
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = downloadStatusText,
                                    color = if (downloadProgress == 100) Color(0xFF4ADE80) else Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "$downloadProgress%",
                                    color = Color(0xFF38BDF8),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            LinearProgressIndicator(
                                progress = { downloadProgress / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(CircleShape),
                                color = if (downloadProgress == 100) Color(0xFF4ADE80) else Color(0xFFE879F9),
                                trackColor = Color(0xFF0A0E17)
                            )

                            if (downloadedSizeText.isNotBlank()) {
                                Text(
                                    text = "Transferred: $downloadedSizeText",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    errorMessage?.let { msg ->
                        Spacer(Modifier.height(14.dp))
                        Text(
                            text = msg,
                            color = Color(0xFFFCA5A5),
                            fontSize = 13.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x557F1D1D))
                                .border(1.dp, Color(0x44EF4444), RoundedCornerShape(14.dp))
                                .padding(14.dp)
                        )
                    }

                    // Video Result & Download Buttons
                    AnimatedVisibility(visible = videoInfo != null) {
                        videoInfo?.let { info ->
                            Column(
                                modifier = Modifier
                                    .padding(top = 14.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(22.dp))
                                    .background(Color(0xAA111625))
                                    .border(1.dp, Color(0x28FFFFFF), RoundedCornerShape(22.dp))
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                if (info.thumbnailUrl.isNotBlank()) {
                                    Box {
                                        AsyncImage(
                                            model = info.thumbnailUrl,
                                            contentDescription = "Preview",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(155.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                        )
                                        if (info.duration.isNotBlank()) {
                                            Text(
                                                text = info.duration,
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier
                                                    .align(Alignment.BottomEnd)
                                                    .padding(8.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(Color(0xCC000000))
                                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0x2238BDF8))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = info.platform,
                                            color = Color(0xFF38BDF8),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = info.title,
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Button(
                                    onClick = {
                                        val fileName = "KDownloader_HD_${System.currentTimeMillis()}.mp4"
                                        startRealTimeDownload(info.hdVideoUrl, fileName, "video/mp4")
                                    },
                                    enabled = !isDownloading,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                    contentPadding = PaddingValues()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(primaryButtonGradient),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.Hd, contentDescription = null, tint = Color.White)
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                if (isDownloading) "Downloading $downloadProgress%..." else "Download Full HD Video (MP4)",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        val fileName = "KDownloader_Audio_${System.currentTimeMillis()}.mp3"
                                        startRealTimeDownload(info.mp3AudioUrl, fileName, "audio/mpeg")
                                    },
                                    enabled = !isDownloading,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(46.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8))
                                ) {
                                    Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color(0xFF38BDF8))
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "Download Audio Only (MP3)",
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                }

                                if (info.qualities.size > 1) {
                                    Text(
                                        text = "All Available Formats:",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        info.qualities.forEach { q ->
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(Color(0xFF1E293B))
                                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                                                    .clickable(enabled = !isDownloading) {
                                                        val mime = when (q.extension) {
                                                            "mp3" -> "audio/mpeg"
                                                            "jpg", "jpeg" -> "image/jpeg"
                                                            "png" -> "image/png"
                                                            else -> "video/mp4"
                                                        }
                                                        val name = "KDownloader_${System.currentTimeMillis()}.${q.extension}"
                                                        startRealTimeDownload(q.url, name, mime)
                                                    }
                                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                                            ) {
                                                Text(
                                                    text = "↓ ${q.label}",
                                                    color = Color(0xFFE2E8F0),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Dock + Copyright Footer
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0x77111625))
                            .border(1.dp, Color(0x22FFFFFF), CircleShape)
                            .padding(horizontal = 18.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        DockIcon(
                            icon = Icons.Rounded.Bolt,
                            tint = Color(0xFF38BDF8),
                            bg = Color(0x2238BDF8),
                            onClick = { Toast.makeText(context, "Multi-Platform HD Engine Ready", Toast.LENGTH_SHORT).show() }
                        )
                        Box(Modifier.width(1.dp).height(18.dp).background(Color(0x22FFFFFF)))
                        DockIcon(
                            icon = Icons.Rounded.Refresh,
                            tint = Color(0xFFF43F5E),
                            bg = Color.Transparent,
                            onClick = {
                                urlInput = ""
                                videoInfo = null
                                errorMessage = null
                                downloadProgress = 0
                                Toast.makeText(context, "Cleared", Toast.LENGTH_SHORT).show()
                            }
                        )
                        Box(Modifier.width(1.dp).height(18.dp).background(Color(0x22FFFFFF)))
                        DockIcon(
                            icon = Icons.Rounded.Key,
                            tint = Color(0xFF38BDF8),
                            bg = Color(0x2238BDF8),
                            onClick = {
                                tempKeyInput = customRapidKey
                                showApiDialog = true
                            }
                        )
                        Box(Modifier.width(1.dp).height(18.dp).background(Color(0x22FFFFFF)))
                        DockIcon(
                            icon = Icons.Rounded.HelpOutline,
                            tint = Color(0xFF4ADE80),
                            bg = Color.Transparent,
                            onClick = { showHelpDialog = true }
                        )
                    }

                    Text(
                        text = "Copyright by : YEOM BROS",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.6.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PlatformPill(
    label: String,
    icon: ImageVector,
    bgColor: Color,
    iconTint: Color
) {
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(bgColor)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(15.dp)
        )
        Text(
            text = label,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DockIcon(
    icon: ImageVector,
    tint: Color,
    bg: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(bg)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(18.dp)
        )
    }
}
