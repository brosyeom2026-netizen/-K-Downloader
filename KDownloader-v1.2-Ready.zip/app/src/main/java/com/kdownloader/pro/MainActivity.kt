package com.kdownloader.pro

import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class VideoInfo(
    val title: String,
    val platform: String,
    val thumbnailUrl: String,
    val hdVideoUrl: String,
    val mp3AudioUrl: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedText = if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            extractFirstUrl(intent.getStringExtra(Intent.EXTRA_TEXT) ?: "")
        } else {
            ""
        }

        setContent {
            KDownloaderApp(initialSharedUrl = sharedText)
        }
    }

    private fun extractFirstUrl(text: String): String {
        val matcher = Pattern.compile("(https?://\S+)").matcher(text)
        return if (matcher.find()) matcher.group(1) ?: text else text
    }
}

@Composable
fun KDownloaderApp(initialSharedUrl: String = "") {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val prefs = remember {
        context.getSharedPreferences("kdownloader_v2_prefs", Context.MODE_PRIVATE)
    }

    var customRapidKey by remember {
        mutableStateOf(prefs.getString("rapidapi_key", "") ?: "")
    }
    var showApiDialog by remember { mutableStateOf(false) }
    var tempKeyInput by remember { mutableStateOf(customRapidKey) }

    var urlInput by remember { mutableStateOf(initialSharedUrl) }
    var isFetching by remember { mutableStateOf(false) }
    var videoInfo by remember { mutableStateOf<VideoInfo?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val gradientBrush = Brush.horizontalGradient(
        colors = listOf(Color(0xFF6366F1), Color(0xFFEC4899))
    )

    fun detectPlatform(url: String): String {
        val lower = url.lowercase()
        return when {
            lower.contains("tiktok.com") -> "TikTok"
            lower.contains("facebook.com") || lower.contains("fb.watch") -> "Facebook Reels"
            lower.contains("youtu.be") || lower.contains("youtube.com") -> {
                if (lower.contains("/shorts/")) "YouTube Shorts" else "YouTube HD"
            }
            else -> "Social Video"
        }
    }

    fun extractUrlFromText(raw: String): String {
        val matcher = Pattern.compile("(https?://\S+)").matcher(raw.trim())
        return if (matcher.find()) matcher.group(1) ?: raw.trim() else raw.trim()
    }

    fun fetchVideoDetails(rawLink: String) {
        val cleanUrl = extractUrlFromText(rawLink)
        if (cleanUrl.isEmpty() || !cleanUrl.startsWith("http")) {
            errorMessage = "Please paste a valid http/https video link first."
            return
        }
        urlInput = cleanUrl
        errorMessage = null
        videoInfo = null
        isFetching = true

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val client = OkHttpClient.Builder()
                        .connectTimeout(25, TimeUnit.SECONDS)
                        .readTimeout(25, TimeUnit.SECONDS)
                        .build()

                    val platform = detectPlatform(cleanUrl)

                    if (customRapidKey.isNotBlank()) {
                        val host = "social-download-all-in-one.p.rapidapi.com"
                        val jsonBody = JSONObject().put("url", cleanUrl).toString()
                        val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

                        val request = Request.Builder()
                            .url("https://$host/v1/social/autolink")
                            .post(requestBody)
                            .addHeader("Content-Type", "application/json")
                            .addHeader("x-rapidapi-key", customRapidKey.trim())
                            .addHeader("x-rapidapi-host", host)
                            .build()

                        client.newCall(request).execute().use { response ->
                            val body = response.body?.string() ?: throw Exception("Empty response")
                            if (!response.isSuccessful) throw Exception("RapidAPI Error (${response.code})")
                            val json = JSONObject(body)
                            val title = json.optString("title", "$platform Video").ifBlank { "$platform Video" }
                            val thumb = json.optString("thumbnail", "")
                            val medias = json.optJSONArray("medias")

                            var hdUrl = ""
                            var mp3Url = ""
                            if (medias != null) {
                                for (i in 0 until medias.length()) {
                                    val item = medias.getJSONObject(i)
                                    val ext = item.optString("extension", "").lowercase()
                                    val quality = item.optString("quality", "").lowercase()
                                    val mediaUrl = item.optString("url", "")
                                    if (mediaUrl.isBlank()) continue
                                    if (ext == "mp4" && (hdUrl.isEmpty() || quality.contains("1080") || quality.contains("hd"))) {
                                        hdUrl = mediaUrl
                                    }
                                    if (ext == "mp3" || ext == "m4a") {
                                        mp3Url = mediaUrl
                                    }
                                }
                            }
                            if (hdUrl.isEmpty()) throw Exception("No MP4 stream returned.")
                            return@withContext VideoInfo(
                                title = title,
                                platform = platform,
                                thumbnailUrl = thumb,
                                hdVideoUrl = hdUrl,
                                mp3AudioUrl = mp3Url.ifEmpty { hdUrl }
                            )
                        }
                    }

                    val mirrors = listOf(
                        "https://api.cobalt.tools/",
                        "https://cobalt-api.kwiatekmiki.com/",
                        "https://co.wuk.sh/"
                    )

                    var lastErr = "Server busy"
                    for (endpoint in mirrors) {
                        try {
                            val videoReqJson = JSONObject()
                                .put("url", cleanUrl)
                                .put("videoQuality", "1080")
                                .toString()

                            val videoReq = Request.Builder()
                                .url(endpoint)
                                .post(videoReqJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                                .addHeader("Accept", "application/json")
                                .addHeader("Content-Type", "application/json")
                                .addHeader("User-Agent", "KDownloader/1.2")
                                .build()

                            val videoUrl = client.newCall(videoReq).execute().use { resp ->
                                val txt = resp.body?.string() ?: ""
                                if (!resp.isSuccessful) {
                                    lastErr = "HTTP ${resp.code}"
                                    ""
                                } else {
                                    val j = JSONObject(txt)
                                    j.optString("url", "")
                                }
                            }

                            if (videoUrl.startsWith("http")) {
                                val audioReqJson = JSONObject()
                                    .put("url", cleanUrl)
                                    .put("downloadMode", "audio")
                                    .put("audioFormat", "mp3")
                                    .toString()

                                val audioReq = Request.Builder()
                                    .url(endpoint)
                                    .post(audioReqJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                                    .addHeader("Accept", "application/json")
                                    .addHeader("Content-Type", "application/json")
                                    .build()

                                val audioUrl = try {
                                    client.newCall(audioReq).execute().use { aResp ->
                                        val aTxt = aResp.body?.string() ?: ""
                                        if (aResp.isSuccessful) JSONObject(aTxt).optString("url", videoUrl) else videoUrl
                                    }
                                } catch (_: Exception) {
                                    videoUrl
                                }

                                return@withContext VideoInfo(
                                    title = "$platform HD Media Ready",
                                    platform = platform,
                                    thumbnailUrl = "",
                                    hdVideoUrl = videoUrl,
                                    mp3AudioUrl = audioUrl.ifEmpty { videoUrl }
                                )
                            }
                        } catch (e: Exception) {
                            lastErr = e.localizedMessage ?: "Mirror busy"
                        }
                    }
                    throw Exception("Server busy ($lastErr). Tap the green Key icon at top-right to add a free RapidAPI backup key.")
                }
                videoInfo = result
            } catch (e: Exception) {
                errorMessage = e.localizedMessage ?: "Failed to fetch video."
            } finally {
                isFetching = false
            }
        }
    }

    LaunchedEffect(initialSharedUrl) {
        if (initialSharedUrl.isNotBlank()) {
            fetchVideoDetails(initialSharedUrl)
        }
    }

    fun startSystemDownload(downloadUrl: String, fileName: String, mimeType: String) {
        if (downloadUrl.isBlank()) {
            Toast.makeText(context, "Download link unavailable.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val request = DownloadManager.Request(Uri.parse(downloadUrl))
                .setTitle(fileName)
                .setDescription("Downloading via K Downloader")
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(context, "Downloading $fileName to Downloads folder!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    if (showApiDialog) {
        AlertDialog(
            onDismissRequest = { showApiDialog = false },
            containerColor = Color(0xFF1E293B),
            title = { Text("Optional Backup API Key", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "K Downloader works without a key by default. If a platform blocks free servers, paste a RapidAPI 'Social Download All In One' key here:",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = tempKeyInput,
                        onValueChange = { tempKeyInput = it },
                        placeholder = { Text("Optional RapidAPI Key...", color = Color(0xFF64748B)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF6366F1),
                            unfocusedBorderColor = Color(0xFF475569)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        customRapidKey = tempKeyInput.trim()
                        prefs.edit().putString("rapidapi_key", customRapidKey).apply()
                        showApiDialog = false
                        Toast.makeText(context, "Settings saved!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                ) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiDialog = false }) {
                    Text("Close", color = Color(0xFF94A3B8))
                }
            }
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(gradientBrush),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "K",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Column {
                        Text(
                            text = "K Downloader",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "FB Reels • TikTok • YouTube & Shorts",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                    }
                }

                IconButton(
                    onClick = {
                        tempKeyInput = customRapidKey
                        showApiDialog = true
                    },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Key,
                        contentDescription = "API Settings",
                        tint = Color(0xFF4ADE80)
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf("YouTube", "Shorts", "TikTok", "FB Reels").forEach { label ->
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), CircleShape)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = label, color = Color(0xFFE2E8F0), fontSize = 12.sp)
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF1E293B))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Paste video link here...", color = Color(0xFF64748B)) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF0F172A),
                        unfocusedContainerColor = Color(0xFF0F172A)
                    ),
                    trailingIcon = {
                        if (urlInput.isNotEmpty()) {
                            IconButton(onClick = { urlInput = ""; videoInfo = null; errorMessage = null }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color(0xFF94A3B8))
                            }
                        }
                    }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val pastedText = clipboardManager.getText()?.text ?: ""
                            if (pastedText.isNotBlank()) {
                                urlInput = pastedText
                                fetchVideoDetails(pastedText)
                            } else {
                                Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6366F1))
                    ) {
                        Icon(Icons.Rounded.ContentPaste, contentDescription = null, tint = Color(0xFF818CF8))
                        Spacer(Modifier.width(6.dp))
                        Text("Paste Link", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = { fetchVideoDetails(urlInput) },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(gradientBrush),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Search, contentDescription = null, tint = Color.White)
                                Spacer(Modifier.width(6.dp))
                                Text("Fetch Video", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            if (isFetching) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF1E293B))
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(color = Color(0xFFEC4899))
                    Text("Fetching video info...", color = Color(0xFFE2E8F0), fontSize = 15.sp)
                }
            }

            errorMessage?.let { msg ->
                Text(
                    text = msg,
                    color = Color(0xFFF87171),
                    fontSize = 14.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF450A0A))
                        .padding(14.dp)
                )
            }

            AnimatedVisibility(visible = videoInfo != null) {
                videoInfo?.let { info ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(22.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFF1E1B4B), Color(0xFF31102F))))
                        ) {
                            if (info.thumbnailUrl.isNotBlank()) {
                                AsyncImage(
                                    model = info.thumbnailUrl,
                                    contentDescription = "Video Thumbnail",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xAA0F172A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Text(
                                text = info.platform,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(10.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xCC6366F1))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = info.title,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Button(
                            onClick = {
                                val fileName = "KDownloader_${System.currentTimeMillis()}.mp4"
                                startSystemDownload(info.hdVideoUrl, fileName, "video/mp4")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            contentPadding = PaddingValues()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(gradientBrush),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Hd, contentDescription = null, tint = Color.White)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "Download HD Video (MP4)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                val fileName = "KDownloader_${System.currentTimeMillis()}.mp3"
                                startSystemDownload(info.mp3AudioUrl, fileName, "audio/mpeg")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEC4899))
                        ) {
                            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color(0xFFF472B6))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Download Audio Only (MP3)",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
