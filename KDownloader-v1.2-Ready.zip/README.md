# K Downloader v1.2
- Fixed XOS / HiOS adaptive launcher icon so it always appears on your home screen!
- Works right away WITHOUT requiring a RapidAPI key!
- Supports Share -> K Downloader directly from TikTok, Facebook, and YouTube!
