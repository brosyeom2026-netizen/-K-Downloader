package com.kdownloader.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

data class VideoInfo(
    val title: String,
    val platform: String,
    val duration: String,
    val thumbnailUrl: String,
    val hdVideoUrl: String,
    val mp3AudioUrl: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KDownloaderApp()
        }
    }
}

@Composable
fun KDownloaderApp() {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var urlInput by remember { mutableStateOf("") }
    var isFetching by remember { mutableStateOf(false) }
    var videoInfo by remember { mutableStateOf<VideoInfo?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Configure your RapidAPI Key here for live extraction
    val rapidApiKey = "YOUR_RAPIDAPI_KEY_HERE"
    val rapidApiHost = "social-download-all-in-one.p.rapidapi.com"

    val gradientBrush = Brush.horizontalGradient(
        colors = listOf(Color(0xFF6366F1), Color(0xFFEC4899))
    )

    fun detectPlatform(url: String): String {
        val lower = url.lowercase()
        return when {
            lower.contains("tiktok.com") -> "TikTok"
            lower.contains("facebook.com") || lower.contains("fb.watch") -> "Facebook Reels"
            lower.contains("youtu.be") || lower.contains("youtube.com") -> {
                if (lower.contains("/shorts/")) "YouTube Shorts" else "YouTube HD"
            }
            else -> "Social Video"
        }
    }

    fun fetchVideoDetails(link: String) {
        val cleanUrl = link.trim()
        if (cleanUrl.isEmpty()) {
            errorMessage = "Please paste a valid video link first."
            return
        }
        errorMessage = null
        videoInfo = null
        isFetching = true

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    if (rapidApiKey == "YOUR_RAPIDAPI_KEY_HERE") {
                        // Built-in preview mode until RapidAPI key is added
                        delay(1100)
                        val platform = detectPlatform(cleanUrl)
                        VideoInfo(
                            title = "$platform Video Ready for HD Download",
                            platform = platform,
                            duration = "01:24",
                            thumbnailUrl = "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&q=80",
                            hdVideoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                            mp3AudioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
                        )
                    } else {
                        val client = OkHttpClient()
                        val encoded = URLEncoder.encode(cleanUrl, "UTF-8")
                        val request = Request.Builder()
                            .url("https://$rapidApiHost/v1/social/autolink?url=$encoded")
                            .get()
                            .addHeader("x-rapidapi-key", rapidApiKey)
                            .addHeader("x-rapidapi-host", rapidApiHost)
                            .build()

                        client.newCall(request).execute().use { response ->
                            val body = response.body?.string() ?: throw Exception("Empty response")
                            val json = JSONObject(body)
                            val title = json.optString("title", "Downloaded Video")
                            val thumb = json.optString("thumbnail", "")
                            val medias = json.optJSONArray("medias")
                            var hdUrl = ""
                            var mp3Url = ""

                            if (medias != null) {
                                for (i in 0 until medias.length()) {
                                    val item = medias.getJSONObject(i)
                                    val ext = item.optString("extension", "")
                                    val quality = item.optString("quality", "")
                                    val mediaUrl = item.optString("url", "")
                                    if (ext == "mp4" && (hdUrl.isEmpty() || quality.contains("1080") || quality.contains("hd", true))) {
                                        hdUrl = mediaUrl
                                    }
                                    if (ext == "mp3" || ext == "m4a") {
                                        mp3Url = mediaUrl
                                    }
                                }
                            }
                            VideoInfo(
                                title = title,
                                platform = detectPlatform(cleanUrl),
                                duration = "HD",
                                thumbnailUrl = thumb,
                                hdVideoUrl = hdUrl,
                                mp3AudioUrl = mp3Url.ifEmpty { hdUrl }
                            )
                        }
                    }
                }
                videoInfo = result
            } catch (e: Exception) {
                errorMessage = "Could not fetch video: ${e.localizedMessage ?: "Check link or API key"}"
            } finally {
                isFetching = false
            }
        }
    }

    fun startSystemDownload(downloadUrl: String, fileName: String, mimeType: String) {
        if (downloadUrl.isBlank()) {
            Toast.makeText(context, "Download link unavailable for this format.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val request = DownloadManager.Request(Uri.parse(downloadUrl))
                .setTitle(fileName)
                .setDescription("Downloading via K Downloader")
                .setMimeType(mimeType)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(context, "Downloading $fileName to Downloads folder...", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(gradientBrush),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "K",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Column {
                    Text(
                        text = "K Downloader",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "FB Reels • TikTok • YouTube & Shorts",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp
                    )
                }
            }

            // Platform Badges
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf("YouTube", "Shorts", "TikTok", "FB Reels").forEach { label ->
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), CircleShape)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = label, color = Color(0xFFE2E8F0), fontSize = 12.sp)
                    }
                }
            }

            // Link Input Card + Paste Button
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF1E293B))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Paste video link here...", color = Color(0xFF64748B)) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF0F172A),
                        unfocusedContainerColor = Color(0xFF0F172A)
                    ),
                    trailingIcon = {
                        if (urlInput.isNotEmpty()) {
                            IconButton(onClick = { urlInput = ""; videoInfo = null }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color(0xFF94A3B8))
                            }
                        }
                    }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // PASTE BUTTON
                    OutlinedButton(
                        onClick = {
                            val pastedText = clipboardManager.getText()?.text ?: ""
                            if (pastedText.isNotBlank()) {
                                urlInput = pastedText
                                fetchVideoDetails(pastedText)
                            } else {
                                Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6366F1))
                    ) {
                        Icon(Icons.Rounded.ContentPaste, contentDescription = null, tint = Color(0xFF818CF8))
                        Spacer(Modifier.width(6.dp))
                        Text("Paste Link", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }

                    // FETCH BUTTON
                    Button(
                        onClick = { fetchVideoDetails(urlInput) },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(gradientBrush),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Search, contentDescription = null, tint = Color.White)
                                Spacer(Modifier.width(6.dp))
                                Text("Fetch Video", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Loading State
            if (isFetching) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF1E293B))
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(color = Color(0xFFEC4899))
                    Text("Fetching video info...", color = Color(0xFFE2E8F0), fontSize = 15.sp)
                }
            }

            // Error Message
            errorMessage?.let { msg ->
                Text(
                    text = msg,
                    color = Color(0xFFF87171),
                    fontSize = 14.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF450A0A))
                        .padding(14.dp)
                )
            }

            // Video Preview & Download Options Card
            AnimatedVisibility(visible = videoInfo != null) {
                videoInfo?.let { info ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(22.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Video Thumbnail Preview
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(195.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF0F172A))
                        ) {
                            AsyncImage(
                                model = info.thumbnailUrl,
                                contentDescription = "Video Thumbnail",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xAA0F172A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Text(
                                text = info.platform,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(10.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xCC6366F1))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = info.title,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        // Download HD Video Button
                        Button(
                            onClick = {
                                val fileName = "KDownloader_${System.currentTimeMillis()}.mp4"
                                startSystemDownload(info.hdVideoUrl, fileName, "video/mp4")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            contentPadding = PaddingValues()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(gradientBrush),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Hd, contentDescription = null, tint = Color.White)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "Download HD Video (MP4)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }

                        // Download MP3 Audio Button
                        OutlinedButton(
                            onClick = {
                                val fileName = "KDownloader_${System.currentTimeMillis()}.mp3"
                                startSystemDownload(info.mp3AudioUrl, fileName, "audio/mpeg")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEC4899))
                        ) {
                            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color(0xFFF472B6))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Download Audio Only (MP3)",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
