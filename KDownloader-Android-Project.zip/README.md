# K Downloader - Android APK Project

## Features Included
- Dark-mode Material 3 UI (`#0F172A` & Indigo-Pink gradients)
- Custom **K Downloader** vector app icon (`ic_launcher.xml`)
- One-tap **Paste Link** button with automatic link fetching
- Video thumbnail preview card with platform detection (YouTube, Shorts, TikTok, FB Reels)
- **Download HD Video (MP4)** and **Download Audio Only (MP3)** saved directly to your phone's `Downloads` folder

## How to Build the APK on Your Phone
1. Create a new repository on GitHub in your phone browser.
2. Extract this ZIP and upload all files (including `.github/workflows/build-apk.yml`) to your GitHub repo.
3. Open the **Actions** tab, select **Build K Downloader APK**, and wait ~3 minutes.
4. Download the **K-Downloader-APK** artifact, unzip it, and tap `app-debug.apk` to install.
